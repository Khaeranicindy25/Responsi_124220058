package com.example.responsi_pam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
